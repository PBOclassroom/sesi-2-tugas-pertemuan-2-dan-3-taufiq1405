/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuan_3;

/**
 *
 * @author taufiqul israt
 */
public class latihan_3 {
    public static void main(String[] args) {
        int value = 10;
        char x;
        x = 'A';
        
System.out.println(value);
System.out.println("The value of x="+x);
}
    
}
