/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pertemuan_3;

/**
 *
 * @author taufiqul israt
 */
public class Pertemuan_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

int a = 10;
short s = 2;
byte b = 6; 
long l = 125362133223l;
float f =65.20298f;
double d = 876.765d;

System.out.println("The integer variable is " + a);
System.out.println("The short variable is " + s);
System.out.println("The byte variable is " + b);
System.out.println("The long variable is " + l);
System.out.println("The float variable is "+f);
System.out.println("The double variable is " + d);
}
}
    
    

