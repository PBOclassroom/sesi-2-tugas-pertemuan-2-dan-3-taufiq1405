/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuan_3;

/**
 *
 * @author taufiqul israt
 */
public class latihan_ahkir_3 {
  

    public static void main(String[] args) {
        int Number = 10;         // Mendefinisikan variabel Number dengan nilai 10
        char letter = 'a';       // Mendefinisikan variabel letter dengan karakter 'a'
        boolean result = true;   // Mendefinisikan variabel result dengan nilai true
        String str = "hello";    // Mendefinisikan variabel str dengan teks "hello"

        // Menampilkan nilai-nilai variabel
        System.out.println("Number = " + Number);
        System.out.println("letter = " + letter);
        System.out.println("result = " + result);
        System.out.println("str = " + str);
    }
}


