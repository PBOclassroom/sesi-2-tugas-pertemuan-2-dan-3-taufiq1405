/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pertemuan2;

/**
 *
 * @author taufiqul israt
 */
public class Pertemuan2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
