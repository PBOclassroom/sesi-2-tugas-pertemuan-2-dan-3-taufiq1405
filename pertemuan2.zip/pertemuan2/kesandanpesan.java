/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pertemuan2;

/**
 *
 * @author taufiqul israt
 */
public class kesandanpesan {
     public static void main(String[] args) {
        System.out.println("Kesan pertama saat menghadiri perkuliahan praktikum OOP");
        System.out.println("Saat pertama kali menghadiri perkuliahan praktikum OOP (Pemrograman Berorientasi Objek), saya merasa dicampuri oleh berbagai emosi");
        System.out.println(" Rasa penasaran mendominasi pikiran saya karena ini adalah awal dari perjalanan saya dalam menjelajahi dunia pemrograman ");
        System.out.println("berbasis objek yang menjadi dasar banyak aplikasi dan perangkat lunak modern. Namun, di samping rasa penasaran itu, ada juga ");
        System.out.println("kebingungan yang menghampiri Beberapa konsep awal dalam OOP terasa agak rumit dan membingungkan.Meskipun begitu,");
        System.out.println(" saya merasa yakin bahwa pemahaman tentang pemrograman berorientasi objek adalah kunci untuk membuka pintu dunia pemrograman yang lebih");
        System.out.println(" luas. Perasaan campuran antara penasaran dan kebingungan ini sebenarnya adalah bagian alami dari proses pembelajaran, ");
        System.out.println(" dan saya siap untuk menghadapinya dengan tekad dan semangat.Saya yakin bahwa dengan usaha dan dedikasi, saya akan mampu mengatasi semua");
        System.out.println(" rintangan ini dan menjadi seorang pemrogram berorientasi objek yang kompeten.");
      
        
        
    }
            
}

