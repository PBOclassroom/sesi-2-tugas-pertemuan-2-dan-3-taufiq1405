/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author taufiqul israt
 */
public class tugaspertemuan2 {
    
public static void main(String[] args) {
        // Ini adalah komentar satu baris

        // Variabel dengan nama yang berbeda-beda karena Java bersifat case sensitive
        String nama = "taufqi";
        String Nama = "TAUFIQ";

        /* Ini adalah komentar multi-baris
           Ini adalah contoh program sederhana
           yang hanya berisi komentar */

        // Menampilkan nilai dari dua variabel yang berbeda kasusnya
        System.out.println("Nilai variabel 'nama': " + nama);
        System.out.println("Nilai variabel 'Nama': " + Nama);
    }
}

