/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pertemuan2;

/**
 *
 * @author taufiqul israt
 */
public class latihan1 {
    
    public static void main(String args[]){
        System.out.println("singgel line comment above");
        //comment line 1
        System.out.println("multi line comment below");
        /*comment line 2
          comment line 3
          comment line 4
        */
        
    }
    
    
}
